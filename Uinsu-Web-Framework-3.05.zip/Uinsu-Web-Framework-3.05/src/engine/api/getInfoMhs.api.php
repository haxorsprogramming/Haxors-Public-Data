<?php

class mhs{}

$mhsData = new mhs;

$mhsData -> username = inputPost('username');
$mhsData -> nama = inputPost('nama');


