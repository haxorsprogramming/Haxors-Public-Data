<?php

class mainClass{}

$mainExtend = new mainClass;

$mainExtend = -> $className[i];
